def test_closest_integer(closest_integer):
    assert closest_integer("-1.9") == -2
    assert closest_integer("-1.9") == -2
    assert closest_integer("-1.9") == -2
