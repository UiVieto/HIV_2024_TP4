def test_closest_integer(closest_integer):
    assert closest_integer("-100.123124") == -100
    assert closest_integer("-100.123124") == -100
    assert closest_integer("-100.123124") ==
